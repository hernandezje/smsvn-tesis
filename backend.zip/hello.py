def hello():
    "print a greeting"

    print("hello")